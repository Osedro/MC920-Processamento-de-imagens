python3 floid_stainberg.py baboon.png
python3 stevenson_arce.py baboon.png
python3 burkes.py baboon.png
python3 sierra.py baboon.png
python3 stucki.py baboon.png
python3 jarvis_judice_ninke.py baboon.png