python3 floid_stainberg.py monalisa.png
python3 stevenson_arce.py monalisa.png
python3 burkes.py monalisa.png
python3 sierra.py monalisa.png
python3 stucki.py monalisa.png
python3 jarvis_judice_ninke.py monalisa.png