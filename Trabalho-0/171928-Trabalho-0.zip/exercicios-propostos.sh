python3 negativo.py city.png
python3 vert-esp.py city.png
python3 intervalo-intensidade.py city.png
python3 linhas-pares.py city.png
python3 reflexao.py city.png
python3 ajuste-gamma.py baboon.png 1.5
python3 ajuste-gamma.py baboon.png 2.5
python3 ajuste-gamma.py baboon.png 3.5
python3 planos-de-bits.py baboon.png
python3 mosaico.py baboon.png 4
python3 combinacao.py baboon.png butterfly.png 0.2
python3 combinacao.py baboon.png butterfly.png 0.5
python3 combinacao.py baboon.png butterfly.png 0.8