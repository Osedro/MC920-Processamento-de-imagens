python3 filtro.py seagull.png 1
python3 filtro.py city.png 2
python3 filtro.py city.png 3
python3 filtro.py city.png 4
python3 filtro_combinado.py seagull.png
python3 filtro.py seagull.png 5
python3 filtro.py city.png 6
python3 filtro.py city.png 7
python3 filtro.py city.png 8
python3 filtro.py city.png 9
python3 filtro.py seagull.png 10
python3 filtro.py city.png 11